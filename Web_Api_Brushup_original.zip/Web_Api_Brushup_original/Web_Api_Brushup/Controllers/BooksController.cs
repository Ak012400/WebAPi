﻿using Azure;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Web_Api_Brushup.Models;
using Web_Api_Brushup.Repository;

namespace Web_Api_Brushup.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BooksController : ControllerBase
    {
        private readonly IBookRepository _bookRepository;
        public BooksController(IBookRepository bookRepository)
        {
            this._bookRepository = bookRepository;
        }

        [HttpGet("")]
        public async Task<IActionResult> GetAllBooks()
        {
            var books= await _bookRepository.GetAllBooksAsync();
            return Ok(books);   
        }

        [HttpPost("")]
        public async Task<ActionResult> SaveBooks([FromBody]BookModel bookModel)
        {
            int result=await _bookRepository.SaveBooksAsync(bookModel);
            if (result==0)
            {
                return BadRequest();
            }
            return Ok(result);
        }
        [HttpGet("{id:int}")]
        public async Task<IActionResult> GetBookById(int id)
        {
            var book = await _bookRepository.GetBookByIdAsync(id);
            return Ok(book);
        }

        [HttpPut("{id:int}")]
        public async Task<IActionResult> UpdateBookById([FromRoute]int id, [FromBody]BookModel book)
        {
           BookModel value= await _bookRepository.UpdateBookById(id,book);
            return Ok(value);
        }

        [HttpPatch("{id:int}")]
        public async Task<IActionResult> UpdateBookByIdPatch([FromRoute] int id, [FromBody] JsonPatchDocument book)
        {
            await _bookRepository.UpdateBookPatchAsync(id, book);
            return Ok();
        }
        [HttpDelete("{id:int}")]
        public async Task<IActionResult> DeletBookByIdAsync(int id)
        {
           int value= await _bookRepository.DeleteBookAsync(id);
            return Ok(value);
        }

    }
}
