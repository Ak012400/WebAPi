﻿using Microsoft.EntityFrameworkCore;
using Web_Api_Brushup.Models;

namespace Web_Api_Brushup.Data
{
    public class BooksStoreContext :DbContext
    {
        public BooksStoreContext(DbContextOptions<BooksStoreContext> options): base(options)
        {

        }

        public DbSet<BookModel> Books { get; set; }

        //protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        //{
        //    optionsBuilder.UseSqlServer("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=Practice;Integrated Security=True;Connect Timeout=30;Encrypt=False;Trust Server Certificate=False;Application Intent=ReadWrite;Multi Subnet Failover=False");
        //    base.OnConfiguring(optionsBuilder);
        //}

    }
}
