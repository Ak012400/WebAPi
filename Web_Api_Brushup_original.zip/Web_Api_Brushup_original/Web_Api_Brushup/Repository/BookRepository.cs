﻿using Azure;
using Microsoft.EntityFrameworkCore;
using Web_Api_Brushup.Data;
using Web_Api_Brushup.Models;

namespace Web_Api_Brushup.Repository
{
    public class BookRepository : IBookRepository
    {
        private readonly BooksStoreContext _context;
        public BookRepository(BooksStoreContext context)
        {
            this._context = context;

        }
        public async Task<List<BookModel>> GetAllBooksAsync()
        {
            var records = await _context.Books.Select(x =>new BookModel()
            {
                Id = x.Id,
                Title = x.Title,
                Description = x.Description,
            }).ToListAsync();

            return records;


        }
        public async Task<BookModel> GetBookByIdAsync(int Id)
        {
            var records = await _context.Books.Where(x => x.Id == Id).Select(x => new BookModel()
            {
                Id = x.Id,
                Title = x.Title,
                Description = x.Description,

            }).FirstOrDefaultAsync();

            return records;


        }
        public async Task<int>  SaveBooksAsync(BookModel book)
        {
           await _context.AddAsync(book);    
          Task<int> results=  _context.SaveChangesAsync();
            if (results != null || results.IsCompletedSuccessfully)
            {
                return results.Result;
            }
           return 0;
        }

        public async Task<BookModel> UpdateBookById(int id,BookModel userbook)
        {
            var book = new BookModel()
            {
                Id = id,
                Title = userbook.Title,
                Description = userbook.Description,
            };

           


            if (book != null)
            {
                _context.Update(book);
                await _context.SaveChangesAsync();
                return book;
            }
            return null;

        }

        public async Task UpdateBookPatchAsync(int bookid, JsonPatchDocument patch)
        {
            var book = await _context.Books.Where(x => x.Id == bookid).FirstOrDefaultAsync();

            if (book != null)
            {
                patch.AppendReplaceRaw("title","name");
                await _context.SaveChangesAsync();
            }

        }

        public async Task<int> DeleteBookAsync(int bookId)
        {
            var book=new BookModel() { Id = bookId };
            if(book != null)
            {

                _context.Books.Remove(book);
              int value=  await _context.SaveChangesAsync();
                if(value > 0)
                {
                    return value;
                }
            }
            return 0;
        }
    }
}
