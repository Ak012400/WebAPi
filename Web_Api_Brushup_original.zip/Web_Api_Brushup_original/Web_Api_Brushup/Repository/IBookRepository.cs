﻿using Azure;
using Web_Api_Brushup.Models;

namespace Web_Api_Brushup.Repository
{
    public interface IBookRepository
    {

        Task<List<BookModel>> GetAllBooksAsync();
        Task<BookModel> GetBookByIdAsync(int id);
        Task<int> SaveBooksAsync(BookModel book);
        Task<BookModel> UpdateBookById(int id, BookModel userbook);
        Task UpdateBookPatchAsync(int bookid,JsonPatchDocument patch);
        Task<int> DeleteBookAsync(int bookId);
    }
}
